package com.uisrael.ms_configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsConfigserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
