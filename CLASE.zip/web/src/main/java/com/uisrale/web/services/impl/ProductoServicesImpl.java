package com.uisrale.web.services.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.uisrale.web.service.IProductoServices;
import com.uisrale.web.services.model.DTO.ProductoDTO;
import com.uisrale.web.util.ConvertJson;

@Service
@Component
public class ProductoServicesImpl  implements IProductoServices{

	@Autowired
	private RestTemplate gestionRest;
	
	@Override
	public List<ProductoDTO> lisProductos() {
		
		List<String> producto = Arrays.asList(
				gestionRest.getForObject("http://localhost:51726/api/producto/listarpro", String.class));
		
		ConvertJson<ProductoDTO> converter = new ConvertJson<>(ProductoDTO.class);
		List<ProductoDTO> productoDTO = converter.convertJsonArray(producto);
		
		return productoDTO;
	}
	

}
