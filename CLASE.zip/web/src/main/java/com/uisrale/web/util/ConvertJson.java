package com.uisrale.web.util;

import java.util.List;

import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ConvertJson<T> {
	
	private final Class<T> objectType; 
	
	private final Gson gson;
	
	
	public ConvertJson(Class<T> objectType) {
		
		this.gson = new Gson();
		
		this.objectType = objectType ;
	}
	
    public List<T> convertJsonArray(List<String> jsonList) {
        Type listType = TypeToken.getParameterized(List.class, objectType).getType();
        return gson.fromJson(String.join("", jsonList), listType);
    }
	

}
