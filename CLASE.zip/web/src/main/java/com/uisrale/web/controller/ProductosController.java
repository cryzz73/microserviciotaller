package com.uisrale.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.uisrale.web.service.IProductoServices;
import com.uisrale.web.services.model.DTO.ProductoDTO;

import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class ProductosController {
	
	@Autowired
	private IProductoServices servicio;
	
	@GetMapping("/producto/listaproducto")
	public String listarproducto (Model model) {
		List<ProductoDTO> resultado = servicio.lisProductos();
		model.addAttribute("lista",resultado);
		
		return "/producto/listaproducto";
	}
	

}
