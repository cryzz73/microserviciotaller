package com.uisrale.web.service;

import java.util.List;

import com.uisrale.web.services.model.DTO.ProductoDTO;

public interface IProductoServices {
	
	public List<ProductoDTO> lisProductos();

}
