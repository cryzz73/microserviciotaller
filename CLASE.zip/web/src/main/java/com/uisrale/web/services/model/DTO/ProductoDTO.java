package com.uisrale.web.services.model.DTO;

public class ProductoDTO {
    
    private int pro_id;
    private String pro_nombre;
    private String pro_descripcion;
    private String pro_precioUni;

    public int getPro_id() {
        return pro_id;
    }

    public void setPro_id(int pro_id) {
        this.pro_id = pro_id;
    }

    public String getPro_nombre() {
        return pro_nombre;
    }

    public void setPro_nombre(String pro_nombre) {
        this.pro_nombre = pro_nombre;
    }

    public String getPro_descripcion() {
        return pro_descripcion;
    }

    public void setPro_descripcion(String pro_descripcion) {
        this.pro_descripcion = pro_descripcion;
    }

    public String getPro_precioUni() {
        return pro_precioUni;
    }

    public void setPro_precioUni(String pro_precioUni) {
        this.pro_precioUni = pro_precioUni;
    }
}
