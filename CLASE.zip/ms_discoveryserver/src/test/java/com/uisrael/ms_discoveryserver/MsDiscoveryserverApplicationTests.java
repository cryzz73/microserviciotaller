package com.uisrael.ms_discoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsDiscoveryserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
