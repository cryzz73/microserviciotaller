package com.example.ms_gestion.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ms_gestion.model.Compras;

public interface IComprasRepository extends JpaRepository<Compras, Integer>{

}
