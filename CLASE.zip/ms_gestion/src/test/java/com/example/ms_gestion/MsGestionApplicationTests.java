package com.example.ms_gestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsGestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
